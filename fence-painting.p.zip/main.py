/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
def findWays(n, dp):
    mod = 1000000007
    if (n<=1):
        return 2
    elif (dp[n]!=-1):
        return dp[n]
    result1 = findWays(n-1, dp)
    result2 = findWays(n-2, dp)
    dp[n] = (result1+result2) % mod
    return dp[n]

def countWays(n):
    dp = [-1] * (n+1)
    return findWays(n, dp)

#-----driver code------
n = int(input("Enter the number of posts: "))
print("Number of ways in which we can paint the fence: ", countWays(n))