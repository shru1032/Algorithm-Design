#include <stdio.h>
void main(){
    int capacity, n, cur_weight, item;
    int used[10];
    float total_profit;
    int i;
    int weight[10];
    int value[10];
   
    printf("Enter the capacity of Knapsack: ");
    scanf("%d", &capacity);
   
    printf("\nEnter the number of items: ");
    scanf("%d", &n);
   
    printf("\nEnter the weight and value of %d item:\n", n);
    for (i=0; i<n; i++){
        printf("Weight[%d]: ", i);
        scanf("%d", &weight[i]);
        printf("Value[%d]: ", i);
        scanf("%d", &value[i]);
    }
   
    for (i=0;i<n;i++){
        used[i]=0;
    }
   
    cur_weight = capacity;
   
    while (cur_weight>0){
        item = -1;
        for (i=0; i<n; i++){
            if ((used[i]==0) && ((item == -1) || ((float)value[i] / weight[i] > (float)value[item]/weight[item])))
                item = i;
        }
        used[item]=1;
        cur_weight -= weight[item];
        total_profit += value[item];
        if (cur_weight>=0){
            printf("\nAdded object %d (%d Rs., %dkg) completely in the bag. Space left: %d.\n", item+1, value[item], weight[item], cur_weight);
        }
        else{
            int item_percent = (int) ((1+(float)cur_weight / weight[item])*100);
            printf("Added %d%% (%dRs., %dkg) of object %d in the bag.\n", item_percent, value[item], weight[item], item+1);
            total_profit -= value[item];
            total_profit += (1+(float)cur_weight/weight[item]) * value[item];
        }
    }
    printf("Filled the bag with objects worth %.2f Rs.\n", total_profit);
}