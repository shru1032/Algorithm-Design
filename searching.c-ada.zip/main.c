/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int binary_search(int arr[],int n,int val);
int rec_binary_search(int arr[],int n, int low, int high, int val);
void sort(int arr[], int n);

void main()
{
    int choice;
    int ch;
    do {
        int arr[20], i, n, val, j;
        printf("\n\nEnter the number of elements: ");
        scanf("%d", &n);
        for (i=0;i<n;i++){
            printf("Enter %dth element:", i+1);
            scanf("%d", &arr[i]);
        }
        printf("The array elements are: \n");
        for (i=0;i<n;i++){
            printf("%d  ", arr[i]);
        }
        printf("\n\nEnter element to be searched: ");
        scanf("%d", &val);
        printf("\n-------Menu-------");
        printf("\n1. Linear Search");
        printf("\n2. Binary Search");
        printf("\n3. Exit");
        printf("\nEnter your choice here: ");
        scanf("%d", &choice);
        switch(choice){
            case 1:
                for (j=0;j<n;j++){
                    if (arr[j]==val){
                        printf("\nElement found at position: %d", j+1);
                    }
                }
                break;
            case 2:
                sort(arr,n);
                printf("\n\n-------Sub-Menu-------");
                printf("\n2.1. Iterative Binary Search");
                printf("\n2.2. Recursive Binary Search");
                printf("\n2.3. Exit");
                printf("\nEnter your choice here: ");
                scanf("%d", &ch);
                switch(ch){
                    case 1:
                        printf("\nElement found at position: %d", binary_search(arr, n, val));
                        break;
                    case 2:
                        printf("\nElement found at position: %d", rec_binary_search(arr, n, 0, n-1, val)+1);
                        break;
                    case 3:
                        printf("\nProgram Ended!");
                        break;
                    default:
                        printf("\nInvalid choice!");
                        break;
                }
                break;
            case 3:
                printf("\nProgram ended!");
                break;
            default:
                printf("\nInavlid choice");
                break;
           
        }
    }while(choice!=3);
}

int binary_search(int arr[],int n,int val){
    int i, mid, low, high;
    low = 0;
    high = n-1;
    while(high-low>1){
        mid = (low+high)/2;
        if (arr[mid]<val){
            low = mid+1;
        }
        else{
            high=mid;
        }
    }
    if (arr[low]==val){
        return low+1;
    }
    else if (arr[high]==val){
        return high+1;
    }
    else{
        return -1;
    }
}

int rec_binary_search(int arr[],int n, int low, int high, int val){
    while(high>=low){
        int mid = low + (high - low )/2;
        if (arr[mid] == val)
            return mid;
        if (arr[mid] > val)
            return rec_binary_search(arr, n, low, mid-1, val);
        return rec_binary_search(arr, n, mid+1, high, val);
    }
    return -1;
}

void sort(int arr[], int n){
    int i, j, t;
    for (i=0; i<n-1; i++){
        for (j=i+1; j<n; j++){
            if (arr[i] > arr[j]){
                t = arr[i];
                arr[i] = arr[j];
                arr[j] = t;
            }
        }
    }
    printf("\nAfter sorting the elements are:\n");
    for(i=0; i<n; i++){
        printf("%d  ", arr[i]);
    }
}